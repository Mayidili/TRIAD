# TRIAD — Triadic Radiomics with Interpretable Adaptive Dominance-relation

Reference implementation of the joint evolutionary optimization framework
described in *"TRIAD: Triadic Radiomics with Interpretable Adaptive
Dominance-Relation Approach for Breast Cancer Receptor Status Prediction"*.

TRIAD co-optimizes filter selection, feature mask, and XGBoost hyperparameters
as a single chromosome under three objectives (1 − AUC, sparsity, feature
robustness), using NSGA-II and three re-implemented NSGA-II-family variants
(CSDR, TS-NSGA-II, RPS-NSGA-II).

> **Scope of this repository.** This is a minimal release containing only the
> joint evolutionary optimization framework itself: chromosome encoding/decoding,
> the multi-objective problem definition, and the NSGA-II algorithm variants.
> It does not include the PyRadiomics feature-extraction pipeline, MedSAM2-based
> segmentation, dataset download scripts, or the external-validation/figure code
> used to produce the results reported in the paper — those depend on
> HPC resources and dataset access agreements (Duke-Breast-Cancer-MRI, RIDER
> Breast MRI, I-SPY1/I-SPY2 via TCIA) and are not part of this minimal package.

## Installation

```bash
pip install -e .
```

Requires Python >= 3.9. This installs the `prism` package in editable mode
(via `pyproject.toml`) so `import prism` and the example script work without
any extra `PYTHONPATH` setup.

## Quick start

Run the included demo, which exercises the full pipeline — chromosome
decoding, evolutionary search, and Pareto front extraction — on synthetic
data so it runs in a few seconds without any real imaging data:

```bash
python examples/run_demo.py
```

This is illustrative only; it does not reproduce the paper's results (those
require the real Duke-Breast-Cancer-MRI feature pool and the full evaluation
budget — see the paper's Methods section).

## Package layout

```
prism/
├── algorithms.py        # build_algorithm(): NSGA2 / CSDR / TSNSGA2 / RPS factory
├── problem.py            # PRISMProblem: the 3-objective pymoo problem definition
├── decode.py              # Chromosome -> filter mask / feature mask / XGBoost hyperparameters
├── feature_stability.py   # ICC(3,1) repeat-scan feature stability (used for objective f3)
└── ec/
    ├── common.py           # Shared NSGA-II-family utilities
    ├── csdr.py              # NSGA-II/CSDR variant
    ├── ts_nsga2.py          # TS-NSGA-II variant
    └── rps_nsga2.py         # RPS-NSGA-II variant
```

## Minimal usage

```python
from prism.algorithms import build_algorithm
from prism.problem import PRISMProblem
from pymoo.optimize import minimize
from pymoo.termination import get_termination

problem = PRISMProblem(
    X_pool=X_pool,                      # (n_samples, n_features) candidate feature pool
    y=y,                                # (n_samples,) binary labels
    patient_ids=patient_ids,            # (n_samples,) for patient-level grouped CV
    feature_to_filter_index=f2f,        # (n_features,) which filter config each feature belongs to
    n_filters=n_filters,
    feature_stability=None,             # optional (n_features,) ICC array, see feature_stability.py
)

algorithm = build_algorithm("NSGA2", n_eval=10000)
res = minimize(problem, algorithm, get_termination("n_eval", 10000), seed=0)
```

## Citation

If you use this code, please cite the paper (citation details to be added
upon publication).

## License

MIT — see [LICENSE](LICENSE). Adjust as needed before publishing.
