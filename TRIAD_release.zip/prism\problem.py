"""
第4/5节设计对应的 pymoo Problem 定义。
染色体: [filter_seg (n_filters) | feature_mask_seg (n_features) | clf_hp_seg (6)]
全部 [0,1] 连续实数编码。

三个目标（均为最小化）:
  f1 = 1 - mean CV AUC
  f2 = 选中特征数 / 总特征数（归一化）
  f3 = 1 - 选中特征在RIDER重复扫描间的平均ICC（特征对采集扰动的鲁棒性，越小越好）

并行化：改用 ElementwiseProblem，配合
  elementwise_runner=StarmapParallelization(pool.starmap)
即可让pymoo自动把同一代内的多个个体分发到多进程并行评估，见 scripts/run_experiment.py。
"""
import numpy as np
from pymoo.core.problem import ElementwiseProblem
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import roc_auc_score
import xgboost as xgb

from prism.decode import decode_filter_segment, decode_feature_mask, decode_classifier_hyperparams


class PRISMProblem(ElementwiseProblem):

    def __init__(self, X_pool, y, patient_ids, feature_to_filter_index, n_filters,
                 feature_stability=None, cv_folds=3, threshold=0.5, random_state=0,
                 **kwargs):
        """
        X_pool: (n_samples, n_features) 预计算好的候选特征池（第4节滤波配置池的全部特征）
        y: (n_samples,) 0/1 受体状态标签（如HER2阳性=1/阴性=0）
        patient_ids: (n_samples,) 患者ID，用于患者级分层K折，避免信息泄漏
        feature_to_filter_index: (n_features,) int，每个特征所属的滤波配置编号
        n_filters: 滤波配置池大小（第4节示例=18）
        feature_stability: (n_features,) 每个候选特征在RIDER重复扫描间的ICC，
            与X_pool的特征顺序/维度对齐。None时f3退化为占位常数0.5（不参与优化压力）。
        """
        self.X_pool = X_pool
        self.y = y
        self.patient_ids = patient_ids
        self.feature_to_filter_index = feature_to_filter_index
        self.n_filters = n_filters
        self.n_features = X_pool.shape[1]
        self.feature_stability = feature_stability
        self.cv_folds = cv_folds
        self.threshold = threshold
        self.random_state = random_state

        n_var = n_filters + self.n_features + 6
        super().__init__(n_var=n_var, n_obj=3, n_constr=0, xl=0.0, xu=1.0, **kwargs)

    def _evaluate(self, chrom, out, *args, **kwargs):
        """
        ElementwiseProblem 的 _evaluate 每次只收到一个个体(chrom, shape=(n_var,))，
        pymoo 在有 elementwise_runner 时会自动把一代内所有个体的这个调用分发到多进程。
        """
        nf = self.n_filters
        g_filter = chrom[:nf]
        g_feat = chrom[nf:nf + self.n_features]
        g_hp = chrom[nf + self.n_features:]

        active_filters = decode_filter_segment(g_filter, self.threshold)
        selected = decode_feature_mask(g_feat, active_filters, self.feature_to_filter_index, self.threshold)

        n_selected = int(selected.sum())
        if n_selected == 0:
            out["F"] = np.array([1.0, 1.0, 1.0])
            return

        hp = decode_classifier_hyperparams(g_hp)
        X_sub = self.X_pool[:, selected]

        # 全程后台无人值守跑几万次评估，单个个体因某一折退化（比如某折内正/负类
        # 缺失导致roc_auc_score报错）不应该让整个EC搜索崩掉——按最差适应度处理，
        # 打印告警后继续，而不是让一个个体拖垮几小时的进化搜索。
        try:
            aucs = []
            skf = StratifiedGroupKFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
            for train_idx, test_idx in skf.split(X_sub, self.y, groups=self.patient_ids):
                clf = xgb.XGBClassifier(
                    max_depth=hp["max_depth"],
                    learning_rate=hp["learning_rate"],
                    n_estimators=hp["n_estimators"],
                    subsample=hp["subsample"],
                    colsample_bytree=hp["colsample_bytree"],
                    reg_lambda=hp["reg_lambda"],
                    eval_metric="logloss",
                    n_jobs=1,  # 每个个体单线程，并行度由跨个体的多进程提供，避免过度订阅CPU
                    verbosity=0,
                )
                clf.fit(X_sub[train_idx], self.y[train_idx])
                proba = clf.predict_proba(X_sub[test_idx])[:, 1]
                aucs.append(roc_auc_score(self.y[test_idx], proba))
        except Exception as e:  # noqa: BLE001
            print(f"WARNING: individual evaluation failed ({type(e).__name__}: {e}), using worst-case fitness")
            out["F"] = np.array([1.0, 1.0, 1.0])
            return

        f1 = 1.0 - float(np.mean(aucs))
        f2 = n_selected / self.n_features
        f3 = self._compute_f3(selected)

        out["F"] = np.array([f1, f2, f3])

    def _compute_f3(self, selected):
        """
        选中特征在RIDER重复扫描间的平均ICC，越低代表选中的特征子集对采集
        噪声/重复扫描扰动越不稳定。f3 = 1 - mean(ICC)，与f1/f2同为"越小越好"。
        """
        if self.feature_stability is None:
            return 0.5
        icc_selected = self.feature_stability[selected]
        icc_selected = icc_selected[~np.isnan(icc_selected)]
        if icc_selected.size == 0:
            return 0.5
        return float(1.0 - np.mean(icc_selected))
