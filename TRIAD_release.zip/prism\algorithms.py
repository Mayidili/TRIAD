"""
第5.1节算法选型实验：NSGA-II（经典基准）+ 3个2020年代NSGA-II家族改进变体
（CSDR/TS-NSGA-II/RPS-NSGA-II，均为按论文公式手工实现，见prism/ec/*）。

NSGA-II/CSDR用pop_size直接指定种群规模；TS-NSGA-II和RPS-NSGA-II的种群规模
由参考方向(reference directions)数量决定，不能独立指定——本设计取
n_partitions=13（3目标下对应105个参考方向），是最接近pop_size=100的取值，
与NSGA2/CSDR的100不完全相等，见课题二设计文档第4节。

2026-09-18更新：种群50/评估5000这组试跑规模的结果显示MOEA可能未充分收敛
（基线对比里LASSO/mRMR能打平TRIAD、RFE反超），按设计文档第5.1节预留的
"若未收敛则回调到种群100×评估10000"上限方案，重新设定如下。
"""
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.util.ref_dirs import get_reference_directions

from prism.ec.csdr import NSGA2_CSDR
from prism.ec.rps_nsga2 import RPS_NSGA2
from prism.ec.ts_nsga2 import TS_NSGA2

POP_SIZE = 100  # 设计文档第5.1节的收敛性回调上限
N_OBJ = 3
N_EVAL_DEFAULT = 10000

# das-dennis参考方向数量由组合数公式C(n_partitions+n_obj-1, n_obj-1)决定，
# 不能任意取整；n_partitions=13、n_obj=3时为105，是最接近POP_SIZE=100的取值。
_REF_DIRS_N_PARTITIONS = 13

ALL_ALGO_NAMES = ["NSGA2", "CSDR", "TSNSGA2", "RPS"]


def _build_ref_dirs(n_obj=N_OBJ):
    return get_reference_directions("das-dennis", n_obj, n_partitions=_REF_DIRS_N_PARTITIONS)


def build_algorithm(name, pop_size=POP_SIZE, n_obj=N_OBJ, n_eval=N_EVAL_DEFAULT, **kwargs):
    """
    n_eval用于估算max_gen，CSDR/TS-NSGA-II的参数退火/阶段切换都依赖这个估计的
    最大代数，需要和实际跑的termination(n_eval)保持一致，由调用方
    （run_experiment.py）传入同一个n_eval，不要各算各的。max_gen必须用该算法
    实际生效的种群规模来除——TSNSGA2/RPS的实际种群规模是参考方向数量（55），
    不是传入的pop_size，两者不一致时max_gen会被低估。
    """
    if name == "NSGA2":
        return NSGA2(pop_size=pop_size, **kwargs)
    if name == "CSDR":
        max_gen = max(n_eval // pop_size, 1)
        return NSGA2_CSDR(pop_size=pop_size, max_gen=max_gen, **kwargs)
    if name == "TSNSGA2":
        ref_dirs = _build_ref_dirs(n_obj)
        max_gen = max(n_eval // len(ref_dirs), 1)
        return TS_NSGA2(ref_dirs=ref_dirs, max_gen=max_gen, **kwargs)
    if name == "RPS":
        ref_dirs = _build_ref_dirs(n_obj)
        return RPS_NSGA2(ref_dirs=ref_dirs, **kwargs)
    raise ValueError(f"未知算法: {name}，可选: {ALL_ALGO_NAMES}")


def build_all_algorithms(pop_size=POP_SIZE, n_obj=N_OBJ, n_eval=N_EVAL_DEFAULT):
    return {name: build_algorithm(name, pop_size=pop_size, n_obj=n_obj, n_eval=n_eval) for name in ALL_ALGO_NAMES}
