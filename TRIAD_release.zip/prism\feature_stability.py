"""
第5节f3目标的数据来源：用RIDER Breast MRI的5例"coffee-break"重复扫描
（同一患者间隔15分钟的两次DCE-MRI），对候选特征池里的每个特征计算
组内相关系数ICC(3,1)，度量该特征对重复扫描/采集噪声的稳定性。

ICC(3,1)（Shrout & Fleiss, 1979，双向混合模型，单次测量，一致性）：
  MSR = 受试者间均方，MSE = 残差均方，k = 测量次数（此处k=2，两次扫描）
  ICC(3,1) = (MSR - MSE) / (MSR + (k-1)*MSE)
负值裁剪为0（表示"不比随机猜测更可靠"，没有意义上更差的"负相关"解释）。
"""
import numpy as np


def _icc_3_1(scan1_col, scan2_col):
    """scan1_col, scan2_col: shape (n_subjects,)，同一特征在两次扫描下的取值，按受试者对齐。"""
    x = np.stack([scan1_col, scan2_col], axis=1)  # (n_subjects, k=2)
    n, k = x.shape

    grand_mean = x.mean()
    subject_means = x.mean(axis=1)
    occasion_means = x.mean(axis=0)

    ss_total = np.sum((x - grand_mean) ** 2)
    ss_rows = k * np.sum((subject_means - grand_mean) ** 2)
    ss_cols = n * np.sum((occasion_means - grand_mean) ** 2)
    ss_error = ss_total - ss_rows - ss_cols

    ms_rows = ss_rows / (n - 1)
    ms_error = ss_error / ((n - 1) * (k - 1))

    denom = ms_rows + (k - 1) * ms_error
    if denom == 0:
        return np.nan
    icc = (ms_rows - ms_error) / denom
    return max(icc, 0.0)


def compute_feature_stability(scan1_matrix, scan2_matrix):
    """
    scan1_matrix, scan2_matrix: shape (n_subjects, n_features)，按受试者、按特征列
    一一对齐（同一特征提取流程、同一列顺序）。
    返回: shape (n_features,) 每个特征的ICC(3,1)，可直接传给 PRISMProblem 的
    feature_stability 参数。
    """
    assert scan1_matrix.shape == scan2_matrix.shape
    n_features = scan1_matrix.shape[1]
    iccs = np.full(n_features, np.nan)
    for j in range(n_features):
        iccs[j] = _icc_3_1(scan1_matrix[:, j], scan2_matrix[:, j])
    return iccs


def build_feature_stability(rider_manifest_csv, extractor, out_npz, canonical_feature_names):
    """
    rider_manifest_csv 列: patient_id, scan1_image_path, scan1_mask_path,
                            scan2_image_path, scan2_mask_path
    canonical_feature_names: 与 build_corpus 产出的 feature_names 顺序一致，
        保证RIDER这边算出的ICC和主特征池的列一一对应。
    """
    import pandas as pd
    from prism.feature_extraction import extract_case

    manifest = pd.read_csv(rider_manifest_csv)
    scan1_rows, scan2_rows = [], []
    for _, row in manifest.iterrows():
        f1 = extract_case(row["scan1_image_path"], row["scan1_mask_path"], extractor)
        f2 = extract_case(row["scan2_image_path"], row["scan2_mask_path"], extractor)
        scan1_rows.append([f1[c] for c in canonical_feature_names])
        scan2_rows.append([f2[c] for c in canonical_feature_names])

    scan1_matrix = np.array(scan1_rows, dtype=np.float64)
    scan2_matrix = np.array(scan2_rows, dtype=np.float64)
    feature_stability = compute_feature_stability(scan1_matrix, scan2_matrix)

    np.savez(out_npz, feature_stability=feature_stability, feature_names=np.array(canonical_feature_names))
    return feature_stability
