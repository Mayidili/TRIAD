"""
CSDR/TS-NSGA-II/RPS-NSGA-II三个算法共用的底层工具：ideal/nadir归一化、
两两夹角、通用的"从支配矩阵构建非支配前沿"排序（带非传递关系的环路保护，
CSDR论文Property 3明确指出SDR/CSDR的并集关系是非传递的，标准fast non-
dominated sort假设的是一个良序的偏序关系，遇到环路会死循环，这里做兜底）。
"""
import numpy as np
from pymoo.util.dominator import Dominator


def normalize_ideal_nadir(F, eps=1e-12):
    ideal = F.min(axis=0)
    nadir = F.max(axis=0)
    span = np.maximum(nadir - ideal, eps)
    return (F - ideal) / span


def pairwise_angles(Fn, eps=1e-12):
    """返回 (n,n) 夹角矩阵（弧度），对角线设为+inf，使其不会被当成"最近邻"。"""
    norms = np.maximum(np.linalg.norm(Fn, axis=1), eps)
    cos = (Fn @ Fn.T) / np.outer(norms, norms)
    cos = np.clip(cos, -1.0, 1.0)
    theta = np.arccos(cos)
    np.fill_diagonal(theta, np.inf)
    return theta


def niche_threshold_angle(theta, a):
    """
    θ̄：对每个个体取到最近邻的夹角，再取这组值里第 ⌊a·N/100⌋ 小(1-indexed)的一个。
    a=50 时对应"⌊N/2⌋"，与原始SDR定义一致。
    """
    n = theta.shape[0]
    nearest = theta.min(axis=1)
    idx = int(np.floor(a * n / 100))
    idx = min(max(idx, 1), n)
    theta_bar = float(np.sort(nearest)[idx - 1])
    # 种群里出现重复/接近重复个体时最近邻夹角会趋于0，theta_bar=0会在CSDR的
    # θ>θ̄分支里造成除零，这里给一个很小的下限保护数值稳定性。
    return max(theta_bar, 1e-9)


def pareto_relation_matrix(F):
    """1 = 行支配列，-1 = 列支配行，0 = 互不支配（不含约束，本课题n_constr=0）。"""
    return Dominator.calc_domination_matrix(F)


def fast_non_dominated_sort_from_matrix(M):
    """
    给定任意(n,n)支配矩阵(约定同 Dominator.calc_domination_matrix：M[i,j]=1表示i支配j)，
    构建非支配前沿列表。相比pymoo自带的fast_non_dominated_sort，这里额外处理了
    "存在支配环、导致部分个体永远无法把dominated计数降到0"的情况：一旦某一轮
    找不到新的0计数个体，就把所有剩余未分级的个体合并成最后一个前沿，打破环，
    而不是死循环。
    """
    n = M.shape[0]
    if n == 0:
        return []

    n_dominated = np.zeros(n, dtype=int)
    dominates = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if M[i, j] == 1:
                dominates[i].append(j)
                n_dominated[j] += 1
            elif M[i, j] == -1:
                dominates[j].append(i)
                n_dominated[i] += 1

    ranked = np.zeros(n, dtype=bool)
    current = [i for i in range(n) if n_dominated[i] == 0]
    for i in current:
        ranked[i] = True
    fronts = [np.array(current, dtype=int)]
    n_ranked = len(current)

    while n_ranked < n:
        nxt = []
        for i in current:
            for j in dominates[i]:
                if ranked[j]:
                    continue
                n_dominated[j] -= 1
                if n_dominated[j] == 0:
                    nxt.append(j)
        if not nxt:
            leftover = np.array([i for i in range(n) if not ranked[i]], dtype=int)
            fronts.append(leftover)
            break
        for i in nxt:
            ranked[i] = True
        n_ranked += len(nxt)
        fronts.append(np.array(nxt, dtype=int))
        current = nxt

    return fronts


def rank_from_fronts(fronts, n):
    rank = np.full(n, len(fronts), dtype=int)
    for r, front in enumerate(fronts):
        rank[front] = r
    return rank


def associate_to_reference_points(Fn, ref_dirs, eps=1e-12):
    """按夹角（等价于按1-cos，argmin结果相同）把每个（已归一化的）个体分配到最近的参考方向。"""
    fn_norms = np.maximum(np.linalg.norm(Fn, axis=1), eps)
    ref_norms = np.maximum(np.linalg.norm(ref_dirs, axis=1), eps)
    cos = (Fn @ ref_dirs.T) / np.outer(fn_norms, ref_norms)
    cos = np.clip(cos, -1.0, 1.0)
    angles = np.arccos(cos)
    return np.argmin(angles, axis=1)


def truncate_by_score(front, score, n_remove, prefer="largest", random_state=None):
    """
    对一个front按score截断，去掉n_remove个"最差"的个体，返回保留下来的索引(front的子集)。
    prefer="largest"：score越大越好（如拥挤度），去掉最小的n_remove个；
    prefer="smallest"：score越小越好（如RPSet_Density/d2距离），去掉最大的n_remove个。
    """
    from pymoo.util.randomized_argsort import randomized_argsort

    order_dir = "descending" if prefer == "largest" else "ascending"
    order = randomized_argsort(score, order=order_dir, method="numpy", random_state=random_state)
    keep = order[: len(front) - n_remove]
    return front[keep]
