"""
TRIAD minimal runnable demo.

Demonstrates the joint evolutionary optimization loop (filter selection +
feature mask + XGBoost hyperparameters, co-optimized as one chromosome under
three objectives) end-to-end on synthetic data, with no dependency on real
DICOM images, PyRadiomics extraction, or HPC resources.

In the paper's actual experiments, X_pool is a candidate feature pool
produced by extracting PyRadiomics features under several filter
configurations from Duke-Breast-Cancer-MRI (see scripts/run_experiment.py
and prism/problem.py in the full research repository). Here, X_pool is
replaced by a synthetic classification dataset with the same shape
(features grouped into pseudo "filter configurations") purely so the full
NSGA-II -> chromosome decoding -> XGBoost evaluation -> Pareto front
pipeline can be run and inspected in a few seconds. Numbers produced by
this script are illustrative only and are not the results reported in the
paper.

Usage:
    python examples/run_demo.py
"""
import numpy as np
from pymoo.optimize import minimize
from pymoo.termination import get_termination
from sklearn.datasets import make_classification

from prism.algorithms import build_algorithm
from prism.problem import PRISMProblem


def make_synthetic_corpus(n_samples=120, n_features=200, n_filters=6, seed=0):
    """Fabricate a candidate feature pool shaped like the real pipeline's:
    n_features features are evenly assigned to n_filters filter configurations."""
    X, y = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_informative=15,
        n_redundant=10,
        random_state=seed,
    )
    feature_to_filter_index = np.arange(n_features) % n_filters
    patient_ids = np.arange(n_samples)  # no repeated patients in synthetic data
    return X, y, patient_ids, feature_to_filter_index, n_filters


def main():
    X_pool, y, patient_ids, feature_to_filter_index, n_filters = make_synthetic_corpus()

    problem = PRISMProblem(
        X_pool=X_pool,
        y=y,
        patient_ids=patient_ids,
        feature_to_filter_index=feature_to_filter_index,
        n_filters=n_filters,
        feature_stability=None,  # no repeat-scan data in this demo -> f3 is a constant 0.5
        cv_folds=3,
        random_state=0,
    )

    # Small budget so the demo finishes in seconds. The paper's experiments use
    # pop_size=100, n_eval=10000 (see prism/algorithms.py, scripts/run_experiment.py).
    n_eval = 300
    algorithm = build_algorithm("NSGA2", pop_size=20, n_eval=n_eval)
    # Other algorithms available: "CSDR", "TSNSGA2", "RPS" (see prism/algorithms.py)
    termination = get_termination("n_eval", n_eval)

    res = minimize(problem, algorithm, termination, seed=0, verbose=True)

    print(f"\nPareto front size: {len(res.F)}")
    best_idx = np.argmin(res.F[:, 0])  # solution with the highest CV AUC (lowest f1 = 1 - AUC)
    f1, f2, f3 = res.F[best_idx]
    print(
        f"Best-AUC solution on the Pareto front: "
        f"AUC={1 - f1:.4f}, sparsity(selected/total)={f2:.4f}, 1-ICC={f3:.4f}"
    )


if __name__ == "__main__":
    main()
