"""
PRISM染色体解码函数。
染色体结构（顺序拼接）：
  [ filter_seg (n_filters维) | feature_mask_seg (n_features维) | clf_hp_seg (6维) ]
全部[0,1]连续实数编码，真实取值/离散选择靠本模块的解码函数换算。
"""
import numpy as np


def linear_decode(g, low, high):
    return low + g * (high - low)


def log_decode(g, low, high):
    return 10.0 ** (np.log10(low) + g * (np.log10(high) - np.log10(low)))


def decode_filter_segment(g_filter, threshold=0.5):
    """
    g_filter: shape (n_filters,)，值域[0,1]。
    返回布尔掩码：哪些滤波配置被选中。

    边界规则：若全部低于threshold，用argmax兜底，强制选中数值最高的一维，
    保证候选特征池不为空。
    """
    active = g_filter > threshold
    if not active.any():
        active = np.zeros_like(g_filter, dtype=bool)
        active[np.argmax(g_filter)] = True
    return active


def decode_feature_mask(g_feat, active_filter_mask, feature_to_filter_index, threshold=0.5):
    """
    g_feat: shape (n_features,)，值域[0,1]。
    active_filter_mask: shape (n_filters,) 布尔数组，来自 decode_filter_segment。
    feature_to_filter_index: shape (n_features,) int数组，
        feature_to_filter_index[j] = 第j个候选特征所属的滤波配置编号
        （只有该滤波配置被选中时，这个特征才有资格被选中）。

    返回: shape (n_features,) 布尔数组，最终选中的特征子集。
    """
    eligible = active_filter_mask[feature_to_filter_index]
    selected = (g_feat > threshold) & eligible
    return selected


# ---- 分类器超参数解码（XGBoost主分类器的6维超参数） ----
XGB_HP_ORDER = ["max_depth", "learning_rate", "n_estimators",
                "subsample", "colsample_bytree", "reg_lambda"]

XGB_HP_SPEC = {
    #            (映射方式,       下界,  上界)
    "max_depth":        ("linear_int", 2,     8),
    "learning_rate":    ("log",        1e-2,  3e-1),
    "n_estimators":     ("linear_int", 50,    500),
    "subsample":        ("linear",     0.5,   1.0),
    "colsample_bytree": ("linear",     0.5,   1.0),
    "reg_lambda":       ("log",        1e-3,  10.0),
}


def decode_classifier_hyperparams(g_hp):
    """g_hp: shape (6,)，值域[0,1]，顺序为 XGB_HP_ORDER。"""
    assert len(g_hp) == len(XGB_HP_ORDER)
    params = {}
    for name, g in zip(XGB_HP_ORDER, g_hp):
        kind, low, high = XGB_HP_SPEC[name]
        if kind == "linear":
            params[name] = float(linear_decode(g, low, high))
        elif kind == "linear_int":
            params[name] = int(round(linear_decode(g, low, high)))
        elif kind == "log":
            params[name] = float(log_decode(g, low, high))
        else:
            raise ValueError(kind)
    return params
