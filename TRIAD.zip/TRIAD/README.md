# TRIAD

Joint multi-objective evolutionary optimization of feature groups, radiomic and kinetic features
and logistic regression regularization for predicting breast cancer hormone receptor status from
dynamic contrast-enhanced MRI.

Each candidate solution is one real-valued chromosome with three segments: 19 feature-group genes
(18 PyRadiomics image types and one kinetic group), a 1732-gene feature mask and one gene for the
penalty C of an L2 logistic regression. Two objectives are minimized: 1 - cross-validated AUC and
the fraction of selected features. Four NSGA-II-family algorithms are provided: NSGA-II, NSGA-II/CSDR,
TS-NSGA-II and RPS-NSGA-II.

## Contents

```
triad/            library
  problem.py      chromosome decoding, objectives, classifier
  algorithms.py   algorithm construction (population 100, 10,000 evaluations)
  ec/             NSGA-II/CSDR, TS-NSGA-II and RPS-NSGA-II
  features.py     PyRadiomics settings and the 44 kinetic features
  segmentation.py MedSAM2 box-prompted segmentation
  geometry.py     orientation and spacing helpers
scripts/
  prepare_duke.py       Duke DICOM -> pre, early and late phases, boxes, manifest
  prepare_ispy.py       BreastDCEDL I-SPY -> true geometry, prompt boxes, reoriented volumes
  segment.py            MedSAM2 segmentation (GPU)
  extract_features.py   radiomic and kinetic features
  run_triad.py          search, algorithm comparison, baselines, nested evaluation, final model, external validation
examples/run_demo.py    short run on synthetic data
```

## Installation

Python 3.10 was used.

```
pip install -r requirements.txt
```

Segmentation additionally needs PyTorch with CUDA and MedSAM2 (https://github.com/bowang-lab/MedSAM2)
with the checkpoint `MedSAM2_MRI_LiverLesion.pt`. A quick check of the optimization code:

```
python examples/run_demo.py
```

## Data

* Duke-Breast-Cancer-MRI, The Cancer Imaging Archive (DICOM, `Annotation_Boxes.xlsx`,
  `Clinical_and_Other_Features.xlsx`, file-path mapping table).
* I-SPY1 and I-SPY2 from the BreastDCEDL release (https://doi.org/10.5281/zenodo.15627233).
  Their NIfTI files carry no voxel geometry; `prepare_ispy.py geometry` reads it from one image of
  the original series in the I-SPY1, I-SPY2 and ACRIN-6698 collections of The Cancer Imaging Archive.

## Reproducing the analysis

```
# discovery cohort
python scripts/prepare_duke.py --dicom-root DUKE_DICOM --mapping MAPPING.xlsx --boxes Annotation_Boxes.xlsx \
    --clinical Clinical_and_Other_Features.xlsx --out duke
python scripts/segment.py --manifest duke/manifest.csv --boxes duke/boxes.json --out duke/masks \
    --checkpoint MedSAM2_MRI_LiverLesion.pt --medsam2-dir MEDSAM2_REPO
python scripts/extract_features.py --manifest duke/manifest.csv --out duke.npz

# external cohorts (repeat with --cohort ISPY2 and the I-SPY2 metadata)
python scripts/prepare_ispy.py geometry --cohort ISPY1 --metadata BreastDCEDL_spy1_metadata.csv --out ispy1
python scripts/prepare_ispy.py native   --cohort ISPY1 --metadata BreastDCEDL_spy1_metadata.csv \
    --dce-dir ISPY1_DCE --mask-dir ISPY1_MASKS --out ispy1
python scripts/segment.py --manifest ispy1/native/manifest.csv --boxes ispy1/native/prompt_boxes.json \
    --out ispy1/native/masks --checkpoint MedSAM2_MRI_LiverLesion.pt --medsam2-dir MEDSAM2_REPO
python scripts/prepare_ispy.py finalize --cohort ISPY1 --metadata BreastDCEDL_spy1_metadata.csv \
    --dce-dir ISPY1_DCE --mask-dir ISPY1_MASKS --out ispy1
python scripts/extract_features.py --manifest ispy1/manifest_medsam2.csv --out ispy1.npz
python scripts/extract_features.py --manifest ispy1/manifest_official.csv --out ispy1_official.npz

# optimization and evaluation
python scripts/run_triad.py split --features duke.npz --out results
for A in NSGA2 CSDR TSNSGA2 RPS; do
  python scripts/run_triad.py search --features duke.npz --out results --scope full --algorithm $A
  for K in 0 1 2 3 4; do
    python scripts/run_triad.py search --features duke.npz --out results --scope fold --fold $K --algorithm $A
  done
done
for M in lasso mrmr elasticnet rfe full; do
  python scripts/run_triad.py baseline --features duke.npz --out results --method $M
done
python scripts/run_triad.py compare  --out results
python scripts/run_triad.py evaluate --features duke.npz --out results
python scripts/run_triad.py final    --features duke.npz --out results --algorithm CSDR
python scripts/run_triad.py external --features duke.npz --out results --external ispy1.npz ispy2.npz
```

Each search run (10 seeds are run by default) takes about half a minute on 32 cores. The outer
folds are stratified by receptor status with seed 2026; the representative solution of each run is
the sparsest solution within 0.01 of the best within-search AUC, and the final model uses the
features selected in at least half of the 10 runs.

## Notes

All iterative solvers (logistic regression, LassoCV, ElasticNetCV) use at most 1000 iterations.

## License

MIT, see `LICENSE`.
