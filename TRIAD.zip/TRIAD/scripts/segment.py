"""MedSAM2 tumor segmentation from box prompts.

The images listed in the manifest (column given by --image-column) must be in acquisition order
(slices, rows, columns); boxes use the same indices. Masks are written with the image geometry,
and the manifest is extended with a 'mask' column. Run on a GPU with MedSAM2 installed.
"""
import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import SimpleITK as sitk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from triad.segmentation import build_predictor, segment  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--boxes", required=True)
    ap.add_argument("--image-column", default="early")
    ap.add_argument("--out", required=True)
    ap.add_argument("--checkpoint", required=True, help="MedSAM2_MRI_LiverLesion.pt")
    ap.add_argument("--medsam2-dir", required=True, help="MedSAM2 repository (for configs/)")
    a = ap.parse_args()
    man = pd.read_csv(a.manifest)
    boxes = json.load(open(a.boxes))
    os.makedirs(a.out, exist_ok=True)
    cwd = os.getcwd()
    os.chdir(a.medsam2_dir)
    predictor = build_predictor(a.checkpoint)
    os.chdir(cwd)
    masks = []
    for _, r in man.iterrows():
        dst = os.path.join(a.out, f"{r.patient_id}_mask.nii.gz")
        if not os.path.exists(dst):
            img = sitk.ReadImage(r[a.image_column])
            mask = segment(predictor, sitk.GetArrayFromImage(img), boxes[r.patient_id])
            out = sitk.GetImageFromArray(mask.astype(np.uint8))
            out.CopyInformation(img)
            sitk.WriteImage(out, dst)
        masks.append(dst)
    man["mask"] = masks
    man.to_csv(a.manifest, index=False)


if __name__ == "__main__":
    main()
