"""TRIAD pipeline: search, algorithm comparison, staged baselines, nested evaluation,
final model and external validation.

Input feature files (.npz) contain X (patients x features), y (0/1), patient_ids and
feature_names, as written by scripts/extract_features.py.

Typical use (see README.md):
  python scripts/run_triad.py split    --features duke.npz --out results
  python scripts/run_triad.py search   --features duke.npz --out results --scope full --algorithm CSDR
  python scripts/run_triad.py search   --features duke.npz --out results --scope fold --fold 0 --algorithm CSDR
  python scripts/run_triad.py baseline --features duke.npz --out results --method lasso
  python scripts/run_triad.py compare  --out results
  python scripts/run_triad.py evaluate --features duke.npz --out results
  python scripts/run_triad.py final    --features duke.npz --out results --algorithm CSDR
  python scripts/run_triad.py external --features duke.npz --out results --external ispy1.npz ispy2.npz
"""
import argparse
import os
import pickle
import sys
import time
import warnings
from multiprocessing import Pool

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import RFECV, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNetCV, LassoCV, LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedGroupKFold, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import QuantileTransformer, StandardScaler

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from triad.algorithms import ALGORITHMS, build_algorithm  # noqa: E402
from triad.features import GROUPS, feature_group  # noqa: E402
from triad.problem import (MAX_ITER, LogisticModel, TriadProblem, build_inner_folds, decode_solution,  # noqa: E402
                           fit_transform_pre, init_worker)

warnings.filterwarnings("ignore", category=ConvergenceWarning)

N_OUTER, OUTER_SEED = 5, 2026
N_EVAL = 10000
TOL = 0.01
THRESHOLDS = (0.30, 0.40, 0.50)
MAIN_RULE, MAIN_THRESHOLD = "tol", 0.50
RULES = ["tol", "knee", "maxauc"]
BASELINES = ["lasso", "mrmr", "elasticnet", "rfe", "full"]
C_GRID = np.logspace(-4, 1, 11)
HV_REF = np.array([0.5, 1.0])


def load_features(path):
    d = np.load(path, allow_pickle=True)
    names = [str(n) for n in d["feature_names"]]
    return {"X": d["X"].astype(float), "y": d["y"].astype(int), "ids": d["patient_ids"], "names": names,
            "group": np.array([feature_group(n) for n in names])}


def parse_seeds(spec):
    if "-" in spec:
        lo, hi = spec.split("-")
        return list(range(int(lo), int(hi) + 1))
    return [int(s) for s in spec.split(",")]


def run_dir(out, scope, fold=None):
    return os.path.join(out, "full") if scope == "full" else os.path.join(out, "nested", f"fold{fold}")


def outer_folds(out):
    return np.load(os.path.join(out, "splits.npz"))["outer_fold"]


def stage_split(d, out):
    of = np.full(len(d["y"]), -1)
    skf = StratifiedGroupKFold(n_splits=N_OUTER, shuffle=True, random_state=OUTER_SEED)
    for k, (_, te) in enumerate(skf.split(d["X"], d["y"], groups=d["ids"])):
        of[te] = k
    os.makedirs(out, exist_ok=True)
    np.savez(os.path.join(out, "splits.npz"), outer_fold=of, patient_ids=d["ids"])
    for k in range(N_OUTER):
        print(f"fold {k}: test {int((of == k).sum())}, positive {int(d['y'][of == k].sum())}")


def stage_search(d, out, scope, fold, algorithm, seeds, n_eval, n_proc):
    from pymoo.optimize import minimize
    from pymoo.termination import get_termination

    X, y = d["X"], d["y"]
    if scope == "fold":
        tr = outer_folds(out) != fold
        X, y = X[tr], y[tr]
    path_dir = run_dir(out, scope, fold)
    os.makedirs(path_dir, exist_ok=True)
    for seed in seeds:
        path = os.path.join(path_dir, f"{algorithm}_seed{seed}.npz")
        if os.path.exists(path):
            continue
        t0 = time.time()
        folds = build_inner_folds(X, y, n_splits=5, random_state=seed)
        with Pool(n_proc, initializer=init_worker, initargs=(folds, len(GROUPS), d["group"])) as pool:
            res = minimize(TriadProblem(len(GROUPS), X.shape[1], pool), build_algorithm(algorithm, n_obj=2, n_eval=n_eval),
                           get_termination("n_eval", n_eval), seed=seed, verbose=False)
        np.savez(path, X=np.atleast_2d(res.X), F=np.atleast_2d(res.F), seconds=time.time() - t0)
        print(f"{scope} {fold} {algorithm} seed {seed}: best inner AUC {1 - res.F[:, 0].min():.4f}, {time.time() - t0:.0f} s")


def representative(F, rule):
    """Row index of the representative solution among the non-dominated rows of F."""
    from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

    nd = NonDominatedSorting().do(F, only_non_dominated_front=True)
    G = F[nd]
    auc, nf = 1 - G[:, 0], G[:, 1]
    if rule == "tol":
        cand = np.flatnonzero(auc >= auc.max() - TOL)
        best = cand[nf[cand] == nf[cand].min()]
        i = best[np.argmax(auc[best])]
    elif rule == "maxauc":
        cand = np.flatnonzero(auc == auc.max())
        i = cand[np.argmin(nf[cand])]
    elif rule == "knee":
        lo, hi = G.min(0), G.max(0)
        i = np.argmin(np.linalg.norm((G - lo) / np.maximum(hi - lo, 1e-12), axis=1))
    else:
        raise ValueError(rule)
    return int(nd[i])


def representatives(path_dir, algorithm, seeds, rule, group):
    masks, Cs = [], []
    for seed in seeds:
        r = np.load(os.path.join(path_dir, f"{algorithm}_seed{seed}.npz"))
        m, C = decode_solution(r["X"][representative(r["F"], rule)], len(GROUPS), group)
        masks.append(m)
        Cs.append(C)
    return np.array(masks), np.array(Cs)


def consensus(masks, t):
    freq = masks.mean(0)
    mask = freq >= t
    if not mask.any():
        mask = freq == freq.max()
    return mask, freq


def mrmr_select(X, y, k=30, random_state=0):
    mi = mutual_info_classif(X, y, random_state=random_state)
    selected = [int(np.argmax(mi))]
    remaining = set(range(X.shape[1])) - set(selected)
    Xn = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-12)
    while len(selected) < k and remaining:
        sel = np.array(selected)
        best, best_score = None, -np.inf
        for f in remaining:
            score = mi[f] - np.mean(np.abs(Xn[:, sel].T @ Xn[:, f]) / X.shape[0])
            if score > best_score:
                best_score, best = score, f
        selected.append(best)
        remaining.remove(best)
    mask = np.zeros(X.shape[1], dtype=bool)
    mask[selected] = True
    return mask


def select_baseline(method, X, y):
    if method == "lasso":
        fit = LassoCV(cv=5, random_state=0, max_iter=MAX_ITER).fit(StandardScaler().fit_transform(X), y.astype(float))
    elif method == "elasticnet":
        fit = ElasticNetCV(l1_ratio=[0.1, 0.3, 0.5, 0.7, 0.9, 0.95, 1.0], cv=5, random_state=0, max_iter=MAX_ITER,
                           n_jobs=-1).fit(StandardScaler().fit_transform(X), y.astype(float))
    elif method == "mrmr":
        return mrmr_select(X, y, k=30, random_state=0)
    elif method == "rfe":
        A, _, _ = fit_transform_pre(X)
        est = LogisticRegression(C=1.0, max_iter=MAX_ITER, class_weight="balanced")
        return RFECV(est, step=0.05, cv=StratifiedKFold(3, shuffle=True, random_state=0), scoring="roc_auc",
                     min_features_to_select=5, n_jobs=-1).fit(A, y).support_
    elif method == "full":
        return np.ones(X.shape[1], bool)
    else:
        raise ValueError(method)
    sel = np.abs(fit.coef_) > 1e-6
    return sel if sel.any() else np.ones(X.shape[1], bool)


def fit_baseline(method, X, y):
    sel = select_baseline(method, SimpleImputer(strategy="median").fit_transform(X), y)
    pipe = make_pipeline(SimpleImputer(strategy="median"),
                         QuantileTransformer(n_quantiles=min(200, len(y)), output_distribution="normal"),
                         LogisticRegression(max_iter=MAX_ITER, class_weight="balanced"))
    gs = GridSearchCV(pipe, {"logisticregression__C": C_GRID}, scoring="roc_auc",
                      cv=StratifiedKFold(5, shuffle=True, random_state=0), n_jobs=-1).fit(X[:, sel], y)
    return sel, gs.best_estimator_


def stage_baseline(d, out, method):
    X, y = d["X"], d["y"]
    os.makedirs(os.path.join(out, "baselines"), exist_ok=True)
    of = outer_folds(out)
    proba, nf = np.full(len(y), np.nan), []
    for k in range(N_OUTER):
        tr, te = of != k, of == k
        sel, model = fit_baseline(method, X[tr], y[tr])
        proba[te] = model.predict_proba(X[te][:, sel])[:, 1]
        nf.append(int(sel.sum()))
        print(f"{method} fold {k}: {sel.sum()} features, outer AUC {roc_auc_score(y[te], proba[te]):.4f}")
    np.savez(os.path.join(out, "baselines", f"{method}.npz"), proba=proba, n_features=np.array(nf))
    sel, model = fit_baseline(method, X, y)
    with open(os.path.join(out, "baselines", f"{method}_full.pkl"), "wb") as f:
        pickle.dump({"mask": sel, "model": model}, f)


def _boot_idx(y, rng):
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    return np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])


def boot_ci(y, p, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    return np.percentile([roc_auc_score(y[i], p[i]) for i in (_boot_idx(y, rng) for _ in range(n))], [2.5, 97.5])


def paired_boot(y, a, b, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    d = np.empty(n)
    for i in range(n):
        idx = _boot_idx(y, rng)
        d[i] = roc_auc_score(y[idx], a[idx]) - roc_auc_score(y[idx], b[idx])
    return np.percentile(d, [2.5, 97.5]), min(2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)


def stage_compare(out, seeds):
    import scikit_posthocs as sp
    from pymoo.indicators.hv import HV
    from pymoo.indicators.igd import IGD
    from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
    from scipy.stats import kruskal

    runs = {a: [np.load(os.path.join(out, "full", f"{a}_seed{s}.npz"))["F"] for s in seeds] for a in ALGORITHMS}
    allF = np.vstack([F for v in runs.values() for F in v])
    ref_front = allF[NonDominatedSorting().do(allF, only_non_dominated_front=True)]
    df = pd.DataFrame([{"algorithm": a, "seed": s, "hv": HV(ref_point=HV_REF)(F), "igd": IGD(ref_front)(F),
                        "best_inner_auc": 1 - F[:, 0].min()} for a, Fs in runs.items() for s, F in zip(seeds, Fs)])
    df.to_csv(os.path.join(out, "algorithm_comparison.csv"), index=False)
    print(df.groupby("algorithm")[["hv", "igd", "best_inner_auc"]].agg(["mean", "std"]).round(4))
    H, p = kruskal(*[df[df.algorithm == a].hv for a in ALGORITHMS])
    print(f"Kruskal-Wallis on hypervolume: H = {H:.3f}, p = {p:.3g}")
    print(sp.posthoc_dunn(df, val_col="hv", group_col="algorithm", p_adjust="bonferroni").round(4))


def stage_evaluate(d, out, algorithms, seeds):
    X, y, group = d["X"], d["y"], d["group"]
    of = outer_folds(out)
    oof, nfeat = {}, {}
    for algo in algorithms:
        for rule in RULES:
            keys = [f"TRIAD-{algo}-{rule}-thr{int(t * 100)}" for t in THRESHOLDS] + [f"TRIAD-{algo}-{rule}-ensemble"]
            for key in keys:
                oof[key], nfeat[key] = np.full(len(y), np.nan), []
            for k in range(N_OUTER):
                tr, te = of != k, of == k
                masks, Cs = representatives(run_dir(out, "fold", k), algo, seeds, rule, group)
                for t, key in zip(THRESHOLDS, keys):
                    mask, _ = consensus(masks, t)
                    oof[key][te] = LogisticModel(mask, float(np.median(Cs))).fit(X[tr], y[tr]).predict(X[te])
                    nfeat[key].append(int(mask.sum()))
                oof[keys[-1]][te] = np.mean([LogisticModel(m, C).fit(X[tr], y[tr]).predict(X[te])
                                             for m, C in zip(masks, Cs) if m.any()], axis=0)
                nfeat[keys[-1]].append(int(np.median(masks.sum(1))))
    for m in BASELINES:
        p = os.path.join(out, "baselines", f"{m}.npz")
        if os.path.exists(p):
            b = np.load(p)
            oof[m], nfeat[m] = b["proba"], b["n_features"].tolist()
    rows = []
    for key, p in oof.items():
        lo, hi = boot_ci(y, p)
        pf = [roc_auc_score(y[of == k], p[of == k]) for k in range(N_OUTER)]
        rows.append({"method": key, "oof_auc": roc_auc_score(y, p), "ci_low": lo, "ci_high": hi,
                     "fold_auc_mean": np.mean(pf), "fold_auc_sd": np.std(pf),
                     "n_features_per_fold": "/".join(map(str, nfeat[key]))})
    summary = pd.DataFrame(rows)
    comps = []
    for algo in algorithms:
        main = f"TRIAD-{algo}-{MAIN_RULE}-thr{int(MAIN_THRESHOLD * 100)}"
        for b in [m for m in BASELINES if m in oof]:
            (lo, hi), p = paired_boot(y, oof[main], oof[b])
            comps.append({"triad": main, "baseline": b, "delta": roc_auc_score(y, oof[main]) - roc_auc_score(y, oof[b]),
                          "ci_low": lo, "ci_high": hi, "p": p, "p_bonferroni": min(p * len(BASELINES), 1.0)})
    summary.to_csv(os.path.join(out, "nested_summary.csv"), index=False)
    pd.DataFrame(comps).to_csv(os.path.join(out, "nested_vs_baselines.csv"), index=False)
    np.savez(os.path.join(out, "nested_oof.npz"), y=y, outer_fold=of, **{k.replace("-", "_"): v for k, v in oof.items()})
    with pd.option_context("display.width", 200, "display.max_rows", 100):
        print(summary.sort_values("oof_auc", ascending=False).round(3))
        print(pd.DataFrame(comps).round(3))


def stage_final(d, out, algorithm, seeds):
    X, y = d["X"], d["y"]
    masks, Cs = representatives(os.path.join(out, "full"), algorithm, seeds, MAIN_RULE, d["group"])
    C = float(np.median(Cs))
    models = {f"thr{int(t * 100)}": LogisticModel(consensus(masks, t)[0], C).fit(X, y) for t in THRESHOLDS}
    models["ensemble"] = [LogisticModel(m, c).fit(X, y) for m, c in zip(masks, Cs) if m.any()]
    freq = masks.mean(0)
    order = np.argsort(-freq)
    pd.DataFrame({"feature": np.array(d["names"])[order], "frequency": freq[order]}).query("frequency > 0").to_csv(
        os.path.join(out, "final_feature_frequency.csv"), index=False)
    with open(os.path.join(out, "final_models.pkl"), "wb") as f:
        pickle.dump({"algorithm": algorithm, "C": C, "models": models, "feature_names": d["names"]}, f)
    print(f"final model ({algorithm}): {int(models['thr50'].mask.sum())} features, C = {C:.4g}")


def stage_external(d, out, external):
    with open(os.path.join(out, "final_models.pkl"), "rb") as f:
        fm = pickle.load(f)
    base = {}
    for m in BASELINES:
        p = os.path.join(out, "baselines", f"{m}_full.pkl")
        if os.path.exists(p):
            with open(p, "rb") as f:
                base[m] = pickle.load(f)
    rows = []
    for path in external:
        e = load_features(path)
        idx = [e["names"].index(n) for n in fm["feature_names"]]
        X, y = e["X"][:, idx], e["y"]
        preds = {f"TRIAD-{k}": (np.mean([m.predict(X) for m in v], 0) if k == "ensemble" else v.predict(X))
                 for k, v in fm["models"].items()}
        for m, b in base.items():
            preds[m] = b["model"].predict_proba(X[:, b["mask"]])[:, 1]
        for key, p in preds.items():
            lo, hi = boot_ci(y, p)
            row = {"cohort": os.path.basename(path), "model": key, "n": len(y), "auc": roc_auc_score(y, p),
                   "ci_low": lo, "ci_high": hi}
            if key in base:
                (dlo, dhi), pv = paired_boot(y, preds["TRIAD-thr50"], p)
                row.update(delta_triad=roc_auc_score(y, preds["TRIAD-thr50"]) - row["auc"], p_bonferroni=min(pv * len(base), 1.0))
            rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(out, "external_summary.csv"), index=False)
    print(df.round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("stage", choices=["split", "search", "baseline", "compare", "evaluate", "final", "external"])
    ap.add_argument("--features", help="discovery feature file (.npz)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--scope", choices=["full", "fold"], default="full")
    ap.add_argument("--fold", type=int)
    ap.add_argument("--algorithm", default="CSDR", choices=ALGORITHMS)
    ap.add_argument("--algorithms", default=",".join(ALGORITHMS))
    ap.add_argument("--seeds", default="0-9")
    ap.add_argument("--n-eval", type=int, default=N_EVAL)
    ap.add_argument("--n-proc", type=int, default=os.cpu_count())
    ap.add_argument("--method", choices=BASELINES)
    ap.add_argument("--external", nargs="+", default=[])
    a = ap.parse_args()
    seeds = parse_seeds(a.seeds)
    d = load_features(a.features) if a.features else None
    if a.stage == "split":
        stage_split(d, a.out)
    elif a.stage == "search":
        stage_search(d, a.out, a.scope, a.fold, a.algorithm, seeds, a.n_eval, a.n_proc)
    elif a.stage == "baseline":
        stage_baseline(d, a.out, a.method)
    elif a.stage == "compare":
        stage_compare(a.out, seeds)
    elif a.stage == "evaluate":
        stage_evaluate(d, a.out, a.algorithms.split(","), seeds)
    elif a.stage == "final":
        stage_final(d, a.out, a.algorithm, seeds)
    else:
        stage_external(d, a.out, a.external)


if __name__ == "__main__":
    main()
