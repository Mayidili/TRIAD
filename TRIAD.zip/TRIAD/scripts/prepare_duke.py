"""Prepare the Duke-Breast-Cancer-MRI cohort.

Writes, for every patient, the pre-contrast, first post-contrast and last post-contrast phases as
NIfTI volumes of shape (slices, rows, columns) with the in-plane pixel spacing and the slice spacing
measured from the image positions; the annotated tumor boxes (JSON); and a manifest CSV.
Slices are ordered as in the original file names of the collection, to which the boxes refer.

Inputs from The Cancer Imaging Archive: the DICOM files (searched below --dicom-root by series UID),
Annotation_Boxes.xlsx, Clinical_and_Other_Features.xlsx and the file-path mapping table.
"""
import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd
import pydicom
import SimpleITK as sitk


def load_mapping(path):
    m = pd.read_excel(path, usecols=["sop_instance_UID", "original_path_and_filename", "classic_path"])
    parts = m.original_path_and_filename.str.split("/")
    return pd.DataFrame({"sop": m.sop_instance_UID, "pid": parts.str[1], "phase": parts.str[2],
                         "index": parts.str[3].str.extract(r"_(\d+)\.dcm$")[0].astype(float),
                         "series_uid": m.classic_path.str.split("/").str[3]})


def find_series_dirs(root):
    dirs = {}
    for d, _, files in os.walk(root):
        if any(f.endswith(".dcm") for f in files):
            dirs[os.path.basename(d)] = d
    return dirs


def read_series(series_dir, index_by_sop):
    ds = [pydicom.dcmread(os.path.join(series_dir, f)) for f in os.listdir(series_dir) if f.endswith(".dcm")]
    ds.sort(key=lambda x: index_by_sop[x.SOPInstanceUID])
    iop = np.array(ds[0].ImageOrientationPatient, float)
    normal = np.cross(iop[:3], iop[3:])
    dz = float(np.median(np.diff(np.sort([np.dot(normal, np.array(x.ImagePositionPatient, float)) for x in ds]))))
    ps = ds[0].PixelSpacing
    vol = np.stack([x.pixel_array.astype(np.float32) for x in ds])
    return vol, (float(ps[1]), float(ps[0]), dz)


def one(args):
    pid, phases, out = args
    paths = {}
    for tag, (series_dir, index_by_sop) in phases.items():
        vol, spacing = read_series(series_dir, index_by_sop)
        img = sitk.GetImageFromArray(vol)
        img.SetSpacing(spacing)
        paths[tag] = os.path.join(out, "images", f"{pid}_{tag}.nii.gz")
        sitk.WriteImage(img, paths[tag])
    return pid, paths


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dicom-root", required=True)
    ap.add_argument("--mapping", required=True, help="Breast-Cancer-MRI-filepath_filename-mapping.xlsx")
    ap.add_argument("--boxes", required=True, help="Annotation_Boxes.xlsx")
    ap.add_argument("--clinical", required=True, help="Clinical_and_Other_Features.xlsx")
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-proc", type=int, default=8)
    ap.add_argument("--patients", nargs="+", help="process only these patients")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "images"), exist_ok=True)

    clin = pd.read_excel(a.clinical, header=[0, 1, 2])
    clin.columns = [c[1] for c in clin.columns]
    label = ((clin["ER"] == 1) | (clin["PR"] == 1)).astype(int)
    label.index = clin.iloc[:, 0]
    boxes = pd.read_excel(a.boxes).set_index("Patient ID")
    json.dump({pid: {"start_row": int(r["Start Row"]), "end_row": int(r["End Row"]), "start_col": int(r["Start Column"]),
                     "end_col": int(r["End Column"]), "start_slice": int(r["Start Slice"]), "end_slice": int(r["End Slice"])}
               for pid, r in boxes.iterrows()}, open(os.path.join(a.out, "boxes.json"), "w"), indent=1)

    mp = load_mapping(a.mapping)
    series_dirs = find_series_dirs(a.dicom_root)
    tasks = []
    for pid, sub in mp.groupby("pid"):
        phases = set(sub.phase)
        last = next((p for p in ["post_4", "post_3", "post_2"] if p in phases), None)
        if (a.patients and pid not in a.patients) or pid not in boxes.index or last is None or not {"pre", "post_1"} <= phases:
            continue
        spec = {}
        for tag, phase in (("pre", "pre"), ("early", "post_1"), ("late", last)):
            s = sub[sub.phase == phase]
            uid = s.series_uid.value_counts().idxmax()
            spec[tag] = (series_dirs[uid], dict(zip(s.sop, s["index"])))
        tasks.append((pid, spec, a.out))
    rows = []
    with ProcessPoolExecutor(a.n_proc) as ex:
        for pid, paths in ex.map(one, tasks):
            rows.append({"patient_id": pid, "label": int(label[pid]), **paths})
    pd.DataFrame(rows).to_csv(os.path.join(a.out, "manifest.csv"), index=False)
    print(f"{len(rows)} patients written to {a.out}")


if __name__ == "__main__":
    main()
