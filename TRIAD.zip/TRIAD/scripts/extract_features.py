"""Radiomic and kinetic features for every patient in a manifest.

Manifest columns: patient_id, label, pre, early, late, mask (paths to volumes on one grid).
Output .npz: X (patients x 1732), y, patient_ids, feature_names (1688 radiomic features in sorted
order followed by the 44 kinetic features).
"""
import argparse
import os
import sys
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd
import SimpleITK as sitk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from triad.features import KINETIC_NAMES, kinetic_features, radiomic_features  # noqa: E402


def read(path):
    return sitk.GetArrayFromImage(sitk.ReadImage(path)).astype(np.float64)


def one(row):
    rad = radiomic_features(row["early"], row["mask"])
    img = sitk.ReadImage(row["early"])
    kin = kinetic_features(read(row["pre"]), read(row["early"]), read(row["late"]), read(row["mask"]) > 0,
                           float(np.prod(img.GetSpacing())))
    return rad, kin


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-proc", type=int, default=8)
    a = ap.parse_args()
    man = pd.read_csv(a.manifest)
    with ProcessPoolExecutor(a.n_proc) as ex:
        res = list(ex.map(one, [r for _, r in man.iterrows()], chunksize=2))
    names = sorted(res[0][0])
    X = np.array([[rad[n] for n in names] + list(kin) for rad, kin in res])
    np.savez(a.out, X=X, y=man.label.values.astype(int), patient_ids=man.patient_id.values,
             feature_names=np.array(names + KINETIC_NAMES))
    print(f"{X.shape[0]} patients, {X.shape[1]} features -> {a.out}")


if __name__ == "__main__":
    main()
