"""Prepare the I-SPY1 and I-SPY2 cohorts from the BreastDCEDL release.

BreastDCEDL stores each phase as a NIfTI array ordered (column, row, slice) with an identity
affine, so voxel spacing and orientation are lost. Three steps restore them:

  geometry  read PixelSpacing, SpacingBetweenSlices and ImageOrientationPatient of the original
            DCE series from The Cancer Imaging Archive (one image per patient)
  native    write the early phase in acquisition order (slice, row, column) and a prompt box from
            the largest connected component of the closed official mask, for scripts/segment.py
  finalize  reorient pre, early and late phases and both masks to the anatomical order of the
            discovery cohort with the true spacing, and write manifests for extract_features.py

Expected file names below --dce-dir / --mask-dir (searched recursively):
  I-SPY1  <pid>_spy1_vis1_acq<k>.nii.gz (k = 0, 1, 2: pre, early, late), <pid>_spy1_vis1_mask.nii.gz
  I-SPY2  <pid>_spy2_vis1_dce_aqc_<k>.nii.gz (k from the metadata columns pre, post_early, post_late),
          <pid>_<pid>_spy2_vis1_mask.nii.gz
"""
import argparse
import io
import json
import os
import ssl
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
import SimpleITK as sitk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from triad.geometry import anatomical_spacing, breastdcedl_to_native, native_to_anatomical, prompt_box  # noqa: E402

API = "https://services.cancerimagingarchive.net/nbia-api/services/v1"
DEFAULT_IOP = {"ISPY1": [0, 1, 0, 0, 0, -1], "ISPY2": [1, 0, 0, 0, 1, 0]}


def index_files(root):
    return {f: os.path.join(d, f) for d, _, fs in os.walk(root) for f in fs if f.endswith(".nii.gz")}


def phase_files(cohort, meta, files):
    """patient -> {pre, early, late, official} file paths."""
    out = {}
    for pid, r in meta.iterrows():
        if cohort == "ISPY1":
            names = {t: f"{pid}_spy1_vis1_acq{k}.nii.gz" for t, k in (("pre", 0), ("early", 1), ("late", 2))}
            names["official"] = f"{pid}_spy1_vis1_mask.nii.gz"
        else:
            if r[["pre", "post_early", "post_late"]].isna().any():
                continue
            names = {t: f"{pid}_spy2_vis1_dce_aqc_{int(r[c])}.nii.gz"
                     for t, c in (("pre", "pre"), ("early", "post_early"), ("late", "post_late"))}
            names["official"] = f"{pid}_{pid}_spy2_vis1_mask.nii.gz"
        if all(n in files for n in names.values()):
            out[pid] = {t: files[n] for t, n in names.items()}
    return out


def _get(url, raw=False):
    ctx = ssl.create_default_context()
    ctx.set_ciphers("DEFAULT@SECLEVEL=1")  # the TCIA server negotiates legacy cipher suites only
    ctx.maximum_version = ssl.TLSVersion.TLSv1_2
    for attempt in range(4):
        try:
            with urllib.request.urlopen(url, context=ctx, timeout=120) as r:
                b = r.read()
            return b if raw else json.loads(b)
        except Exception:  # noqa: BLE001
            if attempt == 3:
                raise


def _is_dce(cohort, desc):
    d = desc.lower()
    if cohort == "ISPY1":  # derived single-phase maps share the geometry of the DCE series
        return desc.endswith(": PE1") or desc.endswith(": PE2")
    return any(k in d for k in ("dce", "dyn", "vibrant")) and not any(
        k in d for k in ("ser", "pe1", "pe2", "mip", "sub", "seg", "analysis"))


def _fetch_one(args):
    cohort, pid = args
    import pydicom

    collection = cohort if cohort == "ISPY1" else ("ACRIN-6698" if pid.startswith("ACRIN") else "ISPY2")
    try:
        series = [s for s in _get(f"{API}/getSeries?Collection={collection}&PatientID={pid}")
                  if _is_dce(cohort, s.get("SeriesDescription", ""))]
        if not series:
            return {"pid": pid, "status": "no_dce"}
        s = sorted(series, key=lambda x: (x["StudyDate"], x["SeriesNumber"]))[0]
        uid = s["SeriesInstanceUID"]
        sop = _get(f"{API}/getSOPInstanceUIDs?SeriesInstanceUID={uid}")[0]["SOPInstanceUID"]
        d = pydicom.dcmread(io.BytesIO(_get(f"{API}/getSingleImage?SeriesInstanceUID={uid}&SOPInstanceUID={sop}", raw=True)),
                            stop_before_pixels=True)
        return {"pid": pid, "status": "ok", "ps_row": float(d.PixelSpacing[0]),
                "thk": float(getattr(d, "SliceThickness", "nan")), "sbs": float(getattr(d, "SpacingBetweenSlices", "nan")),
                "iop": json.dumps([round(float(x), 2) for x in d.ImageOrientationPatient])}
    except Exception as e:  # noqa: BLE001
        return {"pid": pid, "status": f"error: {e}"}


def stage_geometry(a, meta):
    with ThreadPoolExecutor(8) as ex:
        df = pd.DataFrame(ex.map(_fetch_one, [(a.cohort, p) for p in meta.index]))
    df.to_csv(os.path.join(a.out, "geometry.csv"), index=False)
    print(df.status.str.split(":").str[0].value_counts().to_string())


def geometry(a, meta):
    """patient -> (pixel spacing, slice spacing, orientation). The I-SPY2 metadata spacing takes precedence."""
    geo = pd.read_csv(os.path.join(a.out, "geometry.csv")).set_index("pid")
    out = {}
    for pid in meta.index:
        g = geo.loc[pid] if pid in geo.index and geo.loc[pid, "status"] == "ok" else None
        iop = json.loads(g.iop) if g is not None else DEFAULT_IOP[a.cohort]
        if a.cohort == "ISPY2":
            ps, dz = float(meta.loc[pid, "xy_spacing"]), float(meta.loc[pid, "slice_thick"])
        elif g is not None:
            ps, dz = float(g.ps_row), float(g.sbs) if pd.notna(g.sbs) else float(g.thk)
        else:
            continue
        out[pid] = (ps, dz, iop)
    return out


def read(path):
    return sitk.GetArrayFromImage(sitk.ReadImage(path))


def stage_native(a, files):
    nat = os.path.join(a.out, "native")
    os.makedirs(nat, exist_ok=True)
    boxes, rows = {}, []
    for pid, f in files.items():
        box = prompt_box(breastdcedl_to_native(read(f["official"]) > 0))
        if box is None:
            continue
        path = os.path.join(nat, f"{pid}_early.nii.gz")
        sitk.WriteImage(sitk.GetImageFromArray(breastdcedl_to_native(read(f["early"])).astype(np.float32)), path)
        boxes[pid] = box
        rows.append({"patient_id": pid, "early": path})
    json.dump(boxes, open(os.path.join(nat, "prompt_boxes.json"), "w"), indent=1)
    pd.DataFrame(rows).to_csv(os.path.join(nat, "manifest.csv"), index=False)
    print(f"{len(rows)} native images and prompt boxes in {nat}")


def stage_finalize(a, meta, files):
    geo = geometry(a, meta)
    seg = pd.read_csv(os.path.join(a.out, "native", "manifest.csv")).set_index("patient_id")["mask"]
    rows = {"medsam2": [], "official": []}
    for pid, f in files.items():
        if pid not in geo or pid not in seg.index or pd.isna(meta.loc[pid, "HR"]):
            continue
        ps, dz, iop = geo[pid]
        perm = native_to_anatomical(iop)
        spacing = anatomical_spacing(perm, ps, dz)
        paths = {}
        for tag, arr, dtype in (("pre", breastdcedl_to_native(read(f["pre"])), np.float32),
                                ("early", breastdcedl_to_native(read(f["early"])), np.float32),
                                ("late", breastdcedl_to_native(read(f["late"])), np.float32),
                                ("mask_official", breastdcedl_to_native(read(f["official"]) > 0), np.uint8),
                                ("mask_medsam2", read(seg[pid]) > 0, np.uint8)):
            img = sitk.GetImageFromArray(np.ascontiguousarray(arr.transpose(perm)).astype(dtype))
            img.SetSpacing(spacing)
            os.makedirs(os.path.join(a.out, tag), exist_ok=True)
            paths[tag] = os.path.join(a.out, tag, f"{pid}.nii.gz")
            sitk.WriteImage(img, paths[tag])
        for kind in rows:
            rows[kind].append({"patient_id": pid, "label": int(meta.loc[pid, "HR"]), "pre": paths["pre"],
                               "early": paths["early"], "late": paths["late"], "mask": paths[f"mask_{kind}"]})
    for kind, r in rows.items():
        pd.DataFrame(r).to_csv(os.path.join(a.out, f"manifest_{kind}.csv"), index=False)
    print(f"{len(rows['medsam2'])} patients written to {a.out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("stage", choices=["geometry", "native", "finalize"])
    ap.add_argument("--cohort", required=True, choices=["ISPY1", "ISPY2"])
    ap.add_argument("--metadata", required=True, help="BreastDCEDL metadata CSV")
    ap.add_argument("--dce-dir")
    ap.add_argument("--mask-dir")
    ap.add_argument("--out", required=True)
    ap.add_argument("--patients", nargs="+", help="process only these patients")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    meta = pd.read_csv(a.metadata).set_index("pid")
    if a.patients:
        meta = meta.loc[a.patients]
    if a.stage == "geometry":
        stage_geometry(a, meta)
        return
    files = phase_files(a.cohort, meta, {**index_files(a.dce_dir), **index_files(a.mask_dir)})
    if a.stage == "native":
        stage_native(a, files)
    else:
        stage_finalize(a, meta, files)


if __name__ == "__main__":
    main()
