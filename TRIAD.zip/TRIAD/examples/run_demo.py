"""Minimal run of the TRIAD search on synthetic data (a few minutes on a laptop).

Generates 300 patients with 19 feature groups, runs one short search with each algorithm and
prints the representative solution of each run.
"""
import os
import sys
from multiprocessing import Pool

import numpy as np
from pymoo.optimize import minimize
from pymoo.termination import get_termination

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))
from run_triad import representative  # noqa: E402
from triad.algorithms import ALGORITHMS, build_algorithm  # noqa: E402
from triad.problem import TriadProblem, build_inner_folds, decode_solution, init_worker  # noqa: E402


def main(n_eval=1000):
    rng = np.random.default_rng(0)
    n, n_groups, per_group = 300, 19, 12
    X = rng.normal(size=(n, n_groups * per_group))
    group = np.repeat(np.arange(n_groups), per_group)
    logit = 0.9 * X[:, 3] - 0.7 * X[:, 30] + 0.5 * X[:, 200]
    y = (logit + rng.normal(size=n) > 0).astype(int)
    folds = build_inner_folds(X, y, n_splits=5, random_state=0)
    with Pool(4, initializer=init_worker, initargs=(folds, n_groups, group)) as pool:
        for name in ALGORITHMS:
            res = minimize(TriadProblem(n_groups, X.shape[1], pool), build_algorithm(name, n_obj=2, n_eval=n_eval),
                           get_termination("n_eval", n_eval), seed=0, verbose=False)
            i = representative(res.F, "tol")
            mask, C = decode_solution(res.X[i], n_groups, group)
            print(f"{name:8s} inner AUC {1 - res.F[i, 0]:.3f}, {mask.sum():3d} features "
                  f"(informative 3, 30, 200 selected: {mask[[3, 30, 200]].tolist()}), C = {C:.3g}")


if __name__ == "__main__":
    main()
