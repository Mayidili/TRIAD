"""Box-prompted 3D tumor segmentation with MedSAM2 (https://github.com/bowang-lab/MedSAM2).

The box is placed on the central slice of the tumor and the mask is propagated in both
directions through the slices of the acquisition plane; the largest connected component is kept.
Volumes are arrays of shape (slices, rows, columns) in the acquisition plane.
"""
import numpy as np
from skimage import measure

IMG_MEAN = (0.485, 0.456, 0.406)
IMG_STD = (0.229, 0.224, 0.225)


def build_predictor(checkpoint, model_cfg="configs/sam2.1_hiera_t512.yaml"):
    from sam2.build_sam import build_sam2_video_predictor_npz

    return build_sam2_video_predictor_npz(model_cfg, checkpoint)


def normalize_to_uint8(volume, lower_pct=0.5, upper_pct=99.5):
    lo, hi = np.percentile(volume, [lower_pct, upper_pct])
    return ((np.clip(volume, lo, hi) - lo) / max(hi - lo, 1e-6) * 255.0).astype(np.uint8)


def _to_rgb_frames(volume_uint8, size=512):
    from PIL import Image

    out = np.zeros((volume_uint8.shape[0], 3, size, size), dtype=np.float32)
    for i, sl in enumerate(volume_uint8):
        out[i] = np.array(Image.fromarray(sl).convert("RGB").resize((size, size))).transpose(2, 0, 1)
    return out


def segment(predictor, volume, box, device="cuda"):
    """box: dict with start/end_row, start/end_col, start/end_slice (0-based, inclusive)."""
    import torch

    vol = normalize_to_uint8(volume)
    d, h, w = vol.shape
    frames = torch.from_numpy(_to_rgb_frames(vol) / 255.0).to(device)
    mean = torch.tensor(IMG_MEAN, dtype=torch.float32)[:, None, None].to(device)
    std = torch.tensor(IMG_STD, dtype=torch.float32)[:, None, None].to(device)
    frames = (frames - mean) / std
    xyxy = np.array([box["start_col"], box["start_row"], box["end_col"], box["end_row"]])
    key = (box["start_slice"] + box["end_slice"]) // 2

    mask = np.zeros((d, h, w), dtype=np.uint8)
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        state = predictor.init_state(frames, h, w)
        for reverse in (False, True):
            predictor.add_new_points_or_box(inference_state=state, frame_idx=key, obj_id=1, box=xyxy)
            for idx, _, logits in predictor.propagate_in_video(state, reverse=reverse):
                mask[idx, (logits[0] > 0.0).cpu().numpy()[0]] = 1
            predictor.reset_state(state)
    if mask.any():
        lab = measure.label(mask)
        counts = np.bincount(lab.flat)
        counts[0] = 0
        mask = (lab == np.argmax(counts)).astype(np.uint8)
    return mask
