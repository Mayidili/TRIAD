"""TRIAD chromosome, objectives and classifier.

Chromosome: [group genes (n_groups) | feature mask (n_features) | C (1)], all real-valued in [0, 1].
A group is active when its gene exceeds 0.5 (the largest gene is activated if none does); a
feature is selected when its gene exceeds 0.5 and its group is active; C = 10^(-4 + 5x).
Objectives (minimized): f1 = 1 - mean inner cross-validated AUC, f2 = selected fraction.
Classifier: median imputation, quantile transform to a normal distribution, L2 logistic
regression with balanced class weights. Imputation and the quantile transform act feature by
feature, so they are fitted once per inner fold on all features and then sliced, which is
equivalent to refitting them on each selected subset.
"""
import warnings

import numpy as np
from pymoo.core.problem import Problem
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import QuantileTransformer

C_LOW, C_HIGH = 1e-4, 1e1
MAX_ITER = 1000


def decode_c(g):
    return float(10.0 ** (np.log10(C_LOW) + float(g) * (np.log10(C_HIGH) - np.log10(C_LOW))))


def decode_solution(chrom, n_groups, feature_group, threshold=0.5):
    """Return the boolean feature mask and C encoded by one chromosome."""
    n_features = len(feature_group)
    active = chrom[:n_groups] > threshold
    if not active.any():
        active = np.zeros(n_groups, dtype=bool)
        active[np.argmax(chrom[:n_groups])] = True
    selected = (chrom[n_groups:n_groups + n_features] > threshold) & active[feature_group]
    return selected, decode_c(chrom[n_groups + n_features])


def fit_transform_pre(X_tr, X_te=None):
    steps = [SimpleImputer(strategy="median"),
             QuantileTransformer(n_quantiles=min(200, len(X_tr)), output_distribution="normal")]
    A, B = X_tr, X_te
    for s in steps:
        A = s.fit_transform(A)
        if B is not None:
            B = s.transform(B)
    return A, B, steps


def make_lr(C):
    return LogisticRegression(C=C, penalty="l2", solver="lbfgs", max_iter=MAX_ITER, class_weight="balanced")


class LogisticModel:
    """Preprocessing plus logistic regression on a fixed feature mask."""

    def __init__(self, mask, C):
        self.mask, self.C = mask, C

    def fit(self, X, y):
        A, _, self.steps = fit_transform_pre(X[:, self.mask])
        self.clf = make_lr(self.C).fit(A, y)
        return self

    def predict(self, X):
        A = X[:, self.mask]
        for s in self.steps:
            A = s.transform(A)
        return self.clf.predict_proba(A)[:, 1]


def build_inner_folds(X, y, n_splits=5, random_state=0):
    folds = []
    for tr, te in StratifiedKFold(n_splits, shuffle=True, random_state=random_state).split(X, y):
        A, B, _ = fit_transform_pre(X[tr], X[te])
        folds.append((A, y[tr], B, y[te]))
    return folds


# worker state for multiprocessing: the transformed folds are sent once per worker
_W = {}


def init_worker(folds, n_groups, feature_group):
    warnings.filterwarnings("ignore", category=ConvergenceWarning)
    _W.update(folds=folds, n_groups=n_groups, feature_group=feature_group)


def evaluate_one(chrom):
    fg = _W["feature_group"]
    selected, C = decode_solution(chrom, _W["n_groups"], fg)
    if not selected.any():
        return 1.0, 1.0
    aucs = [roc_auc_score(yb, make_lr(C).fit(A[:, selected], ya).decision_function(B[:, selected]))
            for A, ya, B, yb in _W["folds"]]
    return 1.0 - float(np.mean(aucs)), selected.sum() / len(fg)


class TriadProblem(Problem):
    def __init__(self, n_groups, n_features, pool):
        self.pool = pool
        super().__init__(n_var=n_groups + n_features + 1, n_obj=2, xl=0.0, xu=1.0)

    def _evaluate(self, X, out, *args, **kwargs):
        out["F"] = np.array(self.pool.map(evaluate_one, list(X), chunksize=1))
