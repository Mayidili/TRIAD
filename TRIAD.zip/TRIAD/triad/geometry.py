"""Voxel geometry and orientation helpers.

All volumes are handled as arrays in the anatomical order (superior-inferior, anterior-posterior,
right-left), which is the native order of the axial discovery cohort. The BreastDCEDL release of
I-SPY stores arrays as (column, row, slice) with an identity affine, so the true spacing and
orientation are restored from the original DICOM headers.
"""
import json

import numpy as np
from scipy import ndimage


def breastdcedl_to_native(a):
    """BreastDCEDL array (column, row, slice) -> acquisition order (slice, row, column)."""
    return np.ascontiguousarray(np.asarray(a).transpose(2, 1, 0))


def native_to_anatomical(iop):
    """Permutation of the native axes (slice, row, column) that gives (Z, Y, X).

    iop: DICOM ImageOrientationPatient; each native axis is mapped to its dominant patient axis.
    """
    iop = json.loads(iop) if isinstance(iop, str) else iop
    col_dir, row_dir = np.array(iop[:3], float), np.array(iop[3:], float)
    anat = [int(np.argmax(np.abs(d))) for d in (np.cross(col_dir, row_dir), row_dir, col_dir)]
    if sorted(anat) != [0, 1, 2]:
        raise ValueError(f"cannot map orientation {iop}")
    return [anat.index(k) for k in (2, 1, 0)]


def anatomical_spacing(perm, pixel_spacing, slice_spacing):
    """SimpleITK spacing (x, y, z) of the reoriented array."""
    native = [slice_spacing, pixel_spacing, pixel_spacing]
    return tuple(float(v) for v in [native[i] for i in perm][::-1])


def slice_spacing_from_positions(positions, iop):
    """Median distance between adjacent slices along the slice normal."""
    iop = np.asarray(iop, float)
    normal = np.cross(iop[:3], iop[3:])
    z = np.sort([np.dot(normal, np.asarray(p, float)) for p in positions])
    return float(np.median(np.diff(z)))


def prompt_box(mask):
    """Bounding box of the largest connected component after 3D closing (for fragmented enhancement masks)."""
    closed = ndimage.binary_closing(mask, structure=ndimage.generate_binary_structure(3, 1), iterations=2)
    lab, n = ndimage.label(closed)
    if n == 0:
        return None
    comp = lab == (int(np.argmax(ndimage.sum(closed, lab, range(1, n + 1)))) + 1)
    s, r, c = [np.flatnonzero(comp.any(axis=tuple(a for a in range(3) if a != ax))) for ax in range(3)]
    return {"start_slice": int(s.min()), "end_slice": int(s.max()), "start_row": int(r.min()),
            "end_row": int(r.max()), "start_col": int(c.min()), "end_col": int(c.max())}
