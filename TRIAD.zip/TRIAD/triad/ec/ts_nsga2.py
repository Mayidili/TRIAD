"""Two-stage NSGA-II (TS-NSGA-II).

Ming, Gong and Wang, IEEE Trans. Syst. Man Cybern. Syst. 52(10):6222-6234, 2022,
doi:10.1109/TSMC.2022.3143657.
Stage 1 (convergence): subregion PBI dominance, last front truncated by the PBI distance d2.
Stage 2 (diversity): level-based Pareto dominance, then one solution per reference direction.
The stage switches when the generation reaches (1 - 3/(eta*m)) * G_max, with eta = 5.
In Algorithm 2 (line 23) the closest solution to a reference direction is taken as the one
with the largest cosine similarity, which matches the description in the text.
"""
import numpy as np
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.survival import Survival
from pymoo.operators.selection.tournament import TournamentSelection

from triad.ec.common import (associate_to_reference_points, fast_non_dominated_sort_from_matrix,
                             normalize_ideal_nadir, pareto_relation_matrix, rank_from_fronts, truncate_by_score)

THETA_PBI = 5.0
ETA_STAGE = 5


def _compute_pbi(Fn, assoc, ref_dirs, theta=THETA_PBI, eps=1e-12):
    w = ref_dirs[assoc]
    w_unit = w / np.maximum(np.linalg.norm(w, axis=1, keepdims=True), eps)
    d1 = np.sum(Fn * w_unit, axis=1)
    d2 = np.linalg.norm(Fn - d1[:, None] * w_unit, axis=1)
    return d1, d2, d1 + theta * d2


def _spd_fronts(assoc, pbi, n_ref):
    """Front k is the union of the k-th best member (by PBI) of every subregion."""
    groups = [idx[np.argsort(pbi[idx])] for idx in (np.where(assoc == r)[0] for r in range(n_ref)) if len(idx)]
    if not groups:
        return []
    return [np.array([g[k] for g in groups if len(g) > k], dtype=int) for k in range(max(len(g) for g in groups))]


def _compute_levels(Fn, n_p):
    return np.floor(np.clip(Fn, 0.0, 1.0 - 1e-9) * n_p).astype(int).max(axis=1)


def _lpd_fronts(F, level):
    n = F.shape[0]
    M = pareto_relation_matrix(F)
    for i in range(n):
        for j in range(i + 1, n):
            if M[i, j] != 0:
                continue
            if level[i] < level[j]:
                M[i, j], M[j, i] = 1, -1
            elif level[j] < level[i]:
                M[i, j], M[j, i] = -1, 1
    return fast_non_dominated_sort_from_matrix(M)


def compute_stage_state(F, ref_dirs, i_stage, n_p, theta=THETA_PBI):
    """Return rank, diversity score (smaller is better), association and fronts."""
    Fn = normalize_ideal_nadir(F)
    assoc = associate_to_reference_points(Fn, ref_dirs)
    if i_stage == 1:
        _, d2, pbi = _compute_pbi(Fn, assoc, ref_dirs, theta)
        fronts = _spd_fronts(assoc, pbi, len(ref_dirs))
        rank = rank_from_fronts(fronts, len(F)) if fronts else np.zeros(len(F), dtype=int)
        return rank, d2, assoc, fronts
    fronts = _lpd_fronts(F, _compute_levels(Fn, n_p))
    density = np.bincount(assoc, minlength=len(ref_dirs))[assoc].astype(float)
    return rank_from_fronts(fronts, len(F)), density, assoc, fronts


def current_stage(n_gen, max_gen, n_obj, eta=ETA_STAGE):
    return 1 if n_gen < (1 - 3 / (eta * n_obj)) * max_gen else 2


class TSTournament:
    """Binary tournament: front rank, then diversity score, then a random choice."""

    def __init__(self, ref_dirs, max_gen, n_p, theta=THETA_PBI, eta=ETA_STAGE):
        self.ref_dirs, self.max_gen, self.n_p, self.theta, self.eta = ref_dirs, max(int(max_gen), 1), n_p, theta, eta

    def __call__(self, pop, P, algorithm=None, random_state=None, **kwargs):
        rng = random_state if random_state is not None else np.random.default_rng()
        F = pop.get("F").astype(float, copy=False)
        i_stage = current_stage(getattr(algorithm, "n_gen", None) or 0, self.max_gen, F.shape[1], self.eta)
        rank, dm, _, _ = compute_stage_state(F, self.ref_dirs, i_stage, self.n_p, self.theta)
        if P.shape[1] != 2:
            raise ValueError("only binary tournaments are supported")
        S = np.full(P.shape[0], -1, dtype=int)
        for i, (a, b) in enumerate(P):
            if rank[a] != rank[b]:
                S[i] = a if rank[a] < rank[b] else b
            elif dm[a] != dm[b]:
                S[i] = a if dm[a] < dm[b] else b
            else:
                S[i] = a if rng.random() < 0.5 else b
        return S[:, None]


class TSSurvival(Survival):
    def __init__(self, ref_dirs, max_gen, n_p, theta=THETA_PBI, eta=ETA_STAGE):
        super().__init__(filter_infeasible=True)
        self.ref_dirs, self.max_gen, self.n_p, self.theta, self.eta = ref_dirs, max(int(max_gen), 1), n_p, theta, eta

    def _do(self, problem, pop, *args, n_survive=None, algorithm=None, random_state=None, **kwargs):
        F = pop.get("F").astype(float, copy=False)
        i_stage = current_stage(getattr(algorithm, "n_gen", None) or 0, self.max_gen, F.shape[1], self.eta)
        _, diversity, _, fronts = compute_stage_state(F, self.ref_dirs, i_stage, self.n_p, self.theta)

        if i_stage == 1:
            survivors = []
            for front in fronts:
                if len(survivors) + len(front) > n_survive:
                    n_remove = len(survivors) + len(front) - n_survive
                    front = truncate_by_score(front, diversity[front], n_remove, prefer="smallest", random_state=random_state)
                survivors.extend(front.tolist())
                if len(survivors) >= n_survive:
                    break
            for r, front in enumerate(fronts):
                for gi in front:
                    if int(gi) in survivors:
                        pop[int(gi)].set("rank", r)
                        pop[int(gi)].set("crowding", -diversity[int(gi)])
            return pop[survivors]

        # stage 2: collect whole fronts until the pool is large enough, then pick one per direction
        pool = []
        for front in fronts:
            pool.extend(front.tolist())
            if len(pool) >= n_survive:
                break
        pool = np.array(pool, dtype=int)
        Fn_pool = normalize_ideal_nadir(F[pool])
        remaining = np.ones(len(pool), dtype=bool)
        selected = []
        ref_norms = np.maximum(np.linalg.norm(self.ref_dirs, axis=1), 1e-12)
        for w, w_norm in zip(self.ref_dirs, ref_norms):
            if not remaining.any() or len(selected) >= n_survive:
                break
            idx = np.where(remaining)[0]
            cos = (Fn_pool[idx] @ w) / (np.maximum(np.linalg.norm(Fn_pool[idx], axis=1), 1e-12) * w_norm)
            best = idx[np.argmax(cos)]
            selected.append(pool[best])
            remaining[best] = False
        if len(selected) < n_survive:
            selected.extend(pool[remaining][: n_survive - len(selected)].tolist())
        for gi in selected:
            pop[int(gi)].set("rank", 0)
            pop[int(gi)].set("crowding", 0.0)
        return pop[selected]


class TS_NSGA2(NSGA2):
    def __init__(self, ref_dirs, max_gen=100, n_p=None, theta=THETA_PBI, eta=ETA_STAGE, **kwargs):
        n_p = n_p or 2 * ref_dirs.shape[1]
        super().__init__(pop_size=len(ref_dirs),
                         selection=TournamentSelection(func_comp=TSTournament(ref_dirs, max_gen, n_p, theta, eta)),
                         survival=TSSurvival(ref_dirs, max_gen, n_p, theta, eta), **kwargs)
