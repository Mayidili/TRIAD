"""Shared utilities for the dominance-relation variants of NSGA-II."""
import numpy as np
from pymoo.util.dominator import Dominator


def normalize_ideal_nadir(F, eps=1e-12):
    ideal = F.min(axis=0)
    nadir = F.max(axis=0)
    return (F - ideal) / np.maximum(nadir - ideal, eps)


def pairwise_angles(Fn, eps=1e-12):
    """Angle matrix in radians; the diagonal is +inf so that it is never the nearest neighbour."""
    norms = np.maximum(np.linalg.norm(Fn, axis=1), eps)
    cos = np.clip((Fn @ Fn.T) / np.outer(norms, norms), -1.0, 1.0)
    theta = np.arccos(cos)
    np.fill_diagonal(theta, np.inf)
    return theta


def niche_threshold_angle(theta, a):
    """The floor(a*N/100)-th smallest nearest-neighbour angle (a = 50 gives the original SDR niche)."""
    n = theta.shape[0]
    nearest = theta.min(axis=1)
    idx = min(max(int(np.floor(a * n / 100)), 1), n)
    # duplicated individuals give a zero angle; keep the threshold positive
    return max(float(np.sort(nearest)[idx - 1]), 1e-9)


def pareto_relation_matrix(F):
    """M[i, j] = 1 if i dominates j, -1 if j dominates i, 0 otherwise."""
    return Dominator.calc_domination_matrix(F)


def fast_non_dominated_sort_from_matrix(M):
    """Non-dominated sorting for an arbitrary dominance matrix.

    Strengthened dominance relations are not transitive, so cycles are possible. If no new
    front can be formed, all remaining individuals are placed in one last front.
    """
    n = M.shape[0]
    if n == 0:
        return []
    n_dominated = np.zeros(n, dtype=int)
    dominates = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if M[i, j] == 1:
                dominates[i].append(j)
                n_dominated[j] += 1
            elif M[i, j] == -1:
                dominates[j].append(i)
                n_dominated[i] += 1

    ranked = np.zeros(n, dtype=bool)
    current = [i for i in range(n) if n_dominated[i] == 0]
    ranked[current] = True
    fronts = [np.array(current, dtype=int)]
    n_ranked = len(current)
    while n_ranked < n:
        nxt = []
        for i in current:
            for j in dominates[i]:
                if ranked[j]:
                    continue
                n_dominated[j] -= 1
                if n_dominated[j] == 0:
                    nxt.append(j)
        if not nxt:
            fronts.append(np.array([i for i in range(n) if not ranked[i]], dtype=int))
            break
        ranked[nxt] = True
        n_ranked += len(nxt)
        fronts.append(np.array(nxt, dtype=int))
        current = nxt
    return fronts


def rank_from_fronts(fronts, n):
    rank = np.full(n, len(fronts), dtype=int)
    for r, front in enumerate(fronts):
        rank[front] = r
    return rank


def associate_to_reference_points(Fn, ref_dirs, eps=1e-12):
    """Index of the reference direction with the smallest angle to each (normalized) point."""
    fn_norms = np.maximum(np.linalg.norm(Fn, axis=1), eps)
    ref_norms = np.maximum(np.linalg.norm(ref_dirs, axis=1), eps)
    cos = np.clip((Fn @ ref_dirs.T) / np.outer(fn_norms, ref_norms), -1.0, 1.0)
    return np.argmin(np.arccos(cos), axis=1)


def truncate_by_score(front, score, n_remove, prefer="largest", random_state=None):
    """Remove the n_remove worst members of a front; prefer='largest' keeps high scores."""
    from pymoo.util.randomized_argsort import randomized_argsort

    order_dir = "descending" if prefer == "largest" else "ascending"
    order = randomized_argsort(score, order=order_dir, method="numpy", random_state=random_state)
    return front[order[: len(front) - n_remove]]
