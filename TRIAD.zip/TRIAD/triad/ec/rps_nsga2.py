"""NSGA-II with a reference-point-based strengthened dominance relation (RPS-NSGA-II).

Gu, Chen, Chen, Li and Xiong, Inf. Sci. 554:236-255, 2021, doi:10.1016/j.ins.2020.12.025.
Pareto-equivalent solutions are ordered by convergence (sum of normalized objectives) and by
the density of their reference-point subregion. The last front is truncated by density, and
the extreme solutions of the first front are protected by setting their density to zero.
"""
import numpy as np
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.survival import Survival

from triad.ec.common import (associate_to_reference_points, fast_non_dominated_sort_from_matrix,
                             normalize_ideal_nadir, pareto_relation_matrix, truncate_by_score)


def rps_domination_matrix(F, ref_dirs):
    n = F.shape[0]
    Fn = normalize_ideal_nadir(F)
    assoc = associate_to_reference_points(Fn, ref_dirs)
    cov = Fn.sum(axis=1)
    density = np.bincount(assoc, minlength=len(ref_dirs))[assoc].astype(float)
    M = pareto_relation_matrix(F)
    for i in range(n):
        for j in range(i + 1, n):
            if M[i, j] != 0:
                continue
            if assoc[i] == assoc[j]:
                i_dom_j, j_dom_i = cov[i] < cov[j], cov[j] < cov[i]
            else:
                i_dom_j = (cov[i] < cov[j]) and (density[i] < density[j])
                j_dom_i = (cov[j] < cov[i]) and (density[j] < density[i])
            if i_dom_j and not j_dom_i:
                M[i, j], M[j, i] = 1, -1
            elif j_dom_i and not i_dom_j:
                M[i, j], M[j, i] = -1, 1
    return M, density


class RPSSurvival(Survival):
    def __init__(self, ref_dirs):
        super().__init__(filter_infeasible=True)
        self.ref_dirs = ref_dirs

    def _do(self, problem, pop, *args, n_survive=None, random_state=None, **kwargs):
        F = pop.get("F").astype(float, copy=False)
        M, density = rps_domination_matrix(F, self.ref_dirs)
        fronts = fast_non_dominated_sort_from_matrix(M)
        density = density.copy()
        if fronts:
            for obj in range(F.shape[1]):
                density[fronts[0][np.argmin(F[fronts[0], obj])]] = 0.0
        survivors = []
        for rank, front in enumerate(fronts):
            if len(survivors) + len(front) > n_survive:
                n_remove = len(survivors) + len(front) - n_survive
                front = truncate_by_score(front, density[front], n_remove, prefer="smallest", random_state=random_state)
            for gi in front:
                pop[int(gi)].set("rank", rank)
                pop[int(gi)].set("crowding", -density[int(gi)])  # tournament prefers larger values
            survivors.extend(front.tolist())
        return pop[survivors]


class RPS_NSGA2(NSGA2):
    """The population size equals the number of reference directions."""

    def __init__(self, ref_dirs, **kwargs):
        super().__init__(pop_size=len(ref_dirs), survival=RPSSurvival(ref_dirs=ref_dirs), **kwargs)
        self.tournament_type = "comp_by_rank_and_crowding"
