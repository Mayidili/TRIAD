"""Radiomic (PyRadiomics) and kinetic features.

Radiomic features: first post-contrast phase, 1 mm isotropic resampling, z-score normalization,
32 gray-level bins, 18 image types (original, 8 wavelet sub-bands, LoG sigma 1-5 mm, square,
square root, logarithm, exponential) -> 1688 features.
Kinetic features: 44 features from the pre-contrast (S0), first post-contrast (S1) and last
post-contrast (SL) phases inside the tumor mask.
"""
import numpy as np
from scipy.stats import kurtosis, skew

LOG_SIGMAS = [1.0, 2.0, 3.0, 4.0, 5.0]
IMAGE_TYPES = (["original"] + [f"wavelet-{b}" for b in ["LLL", "LLH", "LHL", "LHH", "HLL", "HLH", "HHL", "HHH"]]
               + [f"log-sigma-{s:.1f}".replace(".", "-") + "-mm-3D" for s in LOG_SIGMAS]
               + ["square", "squareroot", "logarithm", "exponential"])
GROUPS = IMAGE_TYPES + ["kinetic"]


def build_extractor():
    from radiomics.featureextractor import RadiomicsFeatureExtractor

    ex = RadiomicsFeatureExtractor(binCount=32, resampledPixelSpacing=[1, 1, 1], interpolator="sitkBSpline",
                                   normalize=True, normalizeScale=100)
    ex.disableAllImageTypes()
    ex.enableImageTypeByName("Original")
    ex.enableImageTypeByName("Wavelet")
    ex.enableImageTypeByName("LoG", customArgs={"sigma": LOG_SIGMAS})
    for t in ["Square", "SquareRoot", "Logarithm", "Exponential"]:
        ex.enableImageTypeByName(t)
    ex.disableAllFeatures()
    for c in ["firstorder", "glcm", "glrlm", "glszm", "gldm", "ngtdm", "shape"]:
        ex.enableFeatureClassByName(c)
    return ex


def radiomic_features(image_path, mask_path, extractor=None):
    r = (extractor or build_extractor()).execute(image_path, mask_path)
    return {k: float(v) for k, v in r.items() if not k.startswith("diagnostics_")}


def feature_group(name):
    """Index of the group (image type or kinetic) a feature belongs to."""
    return GROUPS.index("kinetic" if name.startswith("kinetic_") else name.split("_")[0])


ENH_THRESHOLD = 0.5      # early enhancement defining enhancing voxels
WASHOUT_THRESHOLD = 0.1  # late signal change below -10% washout, above +10% persistent
SER_CLIP = 3.0
S0_FLOOR_FRAC = 0.05     # S0 bounded below by 5% of the 99th percentile of the pre-contrast volume

_MAPS = ["PEearly", "PElate", "SER", "DELTA"]
_STATS = ["Mean", "Median", "Std", "P10", "P25", "P75", "P90", "Skewness", "Kurtosis"]
_EXTRA = ["EnhancingFraction", "WashoutFraction", "PlateauFraction", "PersistentFraction",
          "EnhancingVolume", "WashoutVolume", "HotspotPEearly", "HotspotSER"]
KINETIC_NAMES = [f"kinetic_{m}_{s}" for m in _MAPS for s in _STATS] + [f"kinetic_summary_{e}" for e in _EXTRA]


def _stats(v):
    if v.size < 3:
        return [np.nan] * len(_STATS)
    p10, p25, p75, p90 = np.percentile(v, [10, 25, 75, 90])
    return [v.mean(), np.median(v), v.std(), p10, p25, p75, p90, float(skew(v)), float(kurtosis(v))]


def kinetic_features(s0, s1, sl, mask, voxel_volume_mm3):
    """s0, s1, sl: arrays on the same grid; mask: boolean tumor mask. Returns 44 values ordered as KINETIC_NAMES."""
    assert s0.shape == s1.shape == sl.shape == mask.shape
    floor = S0_FLOOR_FRAC * np.percentile(s0, 99)
    m = mask > 0
    a0, a1, al = s0[m].astype(np.float64), s1[m].astype(np.float64), sl[m].astype(np.float64)
    b0 = np.maximum(a0, floor)
    pe_early = (a1 - a0) / b0
    pe_late = (al - a0) / b0
    delta = (al - a1) / np.maximum(a1, floor)

    enh = pe_early >= ENH_THRESHOLD
    if enh.sum() < 10:
        enh = pe_early >= np.median(pe_early)
    denom = al[enh] - a0[enh]
    ser = np.clip((a1[enh] - a0[enh]) / np.where(np.abs(denom) < 1e-6, 1e-6, denom), 0.0, SER_CLIP)
    d_enh = delta[enh]

    feats = []
    for v in (pe_early, pe_late, ser, d_enh):
        feats += _stats(v)
    washout = d_enh < -WASHOUT_THRESHOLD
    persistent = d_enh > WASHOUT_THRESHOLD
    hot = pe_early >= np.percentile(pe_early, 90)
    hot_enh = hot[enh]
    feats += [enh.sum() / m.sum(), washout.mean(), (~washout & ~persistent).mean(), persistent.mean(),
              enh.sum() * voxel_volume_mm3, washout.sum() * voxel_volume_mm3, pe_early[hot].mean(),
              ser[hot_enh].mean() if hot_enh.any() else np.nan]
    return np.array(feats, dtype=np.float64)
