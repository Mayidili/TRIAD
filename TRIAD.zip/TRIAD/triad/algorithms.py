"""The four NSGA-II-family algorithms compared in the study."""
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.util.ref_dirs import get_reference_directions

from triad.ec.csdr import NSGA2_CSDR
from triad.ec.rps_nsga2 import RPS_NSGA2
from triad.ec.ts_nsga2 import TS_NSGA2

ALGORITHMS = ["NSGA2", "CSDR", "TSNSGA2", "RPS"]
POP_SIZE = 100
# Das-Dennis partitions giving 100 reference directions for two objectives
N_PARTITIONS = {2: 99, 3: 13}


def build_algorithm(name, n_obj=2, n_eval=10000, pop_size=POP_SIZE):
    """n_eval sets the generation budget used by the annealing (CSDR) and stage switch (TS-NSGA-II)."""
    if name == "NSGA2":
        return NSGA2(pop_size=pop_size)
    if name == "CSDR":
        return NSGA2_CSDR(pop_size=pop_size, max_gen=max(n_eval // pop_size, 1))
    ref_dirs = get_reference_directions("das-dennis", n_obj, n_partitions=N_PARTITIONS[n_obj])
    if name == "TSNSGA2":
        return TS_NSGA2(ref_dirs=ref_dirs, max_gen=max(n_eval // len(ref_dirs), 1))
    if name == "RPS":
        return RPS_NSGA2(ref_dirs=ref_dirs)
    raise ValueError(f"unknown algorithm {name}; choose from {ALGORITHMS}")
